import React, { useState, useEffect } from "react";
import axios from "axios";

function App() {
  const [events, setEvents] = useState([]);
  const [form, setForm] = useState({ title: "", date: "", description: "" });
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    const res = await axios.get("http://localhost:5000/events");
    setEvents(res.data);
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title || !form.date) {
      alert("Title and Date are required");
      return;
    }

    if (editingId) {
      await axios.put(`http://localhost:5000/events/${editingId}`, form);
      setEditingId(null);
    } else {
      await axios.post("http://localhost:5000/events", form);
    }
    setForm({ title: "", date: "", description: "" });
    fetchEvents();
  };

  const handleEdit = (event) => {
    setForm({
      title: event.title,
      date: event.date.slice(0, 10),
      description: event.description || "",
    });
    setEditingId(event._id);
  };

  const handleDelete = async (id) => {
    if (window.confirm("Delete this event?")) {
      await axios.delete(`http://localhost:5000/events/${id}`);
      fetchEvents();
    }
  };

  return (
    <div style={{ maxWidth: 600, margin: "auto", padding: 20 }}>
      <h2>📅 Event Scheduler</h2>

      <form onSubmit={handleSubmit} style={{ marginBottom: 20 }}>
        <input
          name="title"
          value={form.title}
          onChange={handleChange}
          placeholder="Event Title"
          required
          style={{ width: "100%", padding: 8, marginBottom: 8 }}
        />
        <input
          type="date"
          name="date"
          value={form.date}
          onChange={handleChange}
          required
          style={{ width: "100%", padding: 8, marginBottom: 8 }}
        />
        <textarea
          name="description"
          value={form.description}
          onChange={handleChange}
          placeholder="Description (optional)"
          rows={3}
          style={{ width: "100%", padding: 8, marginBottom: 8 }}
        />
        <button type="submit" style={{ padding: 10 }}>
          {editingId ? "Update Event" : "Add Event"}
        </button>
      </form>

      <h3>Upcoming Events</h3>
      {events.length === 0 ? (
        <p>No events found</p>
      ) : (
        <ul style={{ listStyle: "none", paddingLeft: 0 }}>
          {events.map((event) => (
            <li
              key={event._id}
              style={{
                border: "1px solid #ccc",
                marginBottom: 8,
                padding: 8,
                borderRadius: 5,
              }}
            >
              <strong>{event.title}</strong> -{" "}
              {new Date(event.date).toLocaleDateString()}
              <p>{event.description}</p>
              <button
                onClick={() => handleEdit(event)}
                style={{ marginRight: 10 }}
              >
                Edit
              </button>
              <button onClick={() => handleDelete(event._id)}>Delete</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default App;
