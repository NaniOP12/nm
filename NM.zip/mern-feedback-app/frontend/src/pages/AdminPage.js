import React, { useState } from 'react';
import axios from 'axios';

function AdminPage() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [feedbacks, setFeedbacks] = useState([]);
  const [filter, setFilter] = useState({ course: '', faculty: '' });
  const [credentials, setCredentials] = useState({ username: '', password: '' });

  const login = async () => {
    try {
      await axios.post('http://localhost:5000/api/admin/login', credentials);
      setLoggedIn(true);
      fetchFeedbacks();
    } catch {
      alert('Login failed');
    }
  };

  const fetchFeedbacks = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/admin/feedbacks', { params: filter });
      setFeedbacks(response.data);
    } catch {
      alert('Fetch failed');
    }
  };

  return !loggedIn ? (
    <div>
      <h2>Admin Login</h2>
      <input placeholder="Username" onChange={(e) => setCredentials({ ...credentials, username: e.target.value })} />
      <input type="password" placeholder="Password" onChange={(e) => setCredentials({ ...credentials, password: e.target.value })} />
      <button onClick={login}>Login</button>
    </div>
  ) : (
    <div>
      <h2>All Feedbacks</h2>
      <input placeholder="Course" onChange={(e) => setFilter({ ...filter, course: e.target.value })} />
      <input placeholder="Faculty" onChange={(e) => setFilter({ ...filter, faculty: e.target.value })} />
      <button onClick={fetchFeedbacks}>Filter</button>
      <table border="1">
        <thead>
          <tr><th>Name</th><th>Course</th><th>Faculty</th><th>Comments</th><th>Rating</th></tr>
        </thead>
        <tbody>
          {feedbacks.map((f, idx) => (
            <tr key={idx}>
              <td>{f.studentName}</td><td>{f.course}</td><td>{f.faculty}</td>
              <td>{f.comments}</td><td>{f.rating}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default AdminPage;