import React, { useState } from 'react';
import axios from 'axios';

function StudentPage() {
  const [formData, setFormData] = useState({
    studentName: '', course: '', faculty: '', comments: '', rating: 1,
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/feedback', formData);
      alert('Feedback submitted!');
    } catch {
      alert('Failed to submit.');
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Student Feedback Form</h2>
      <form onSubmit={handleSubmit}>
        <input name="studentName" placeholder="Your Name" onChange={handleChange} required /><br />
        <input name="course" placeholder="Course Name" onChange={handleChange} required /><br />
        <input name="faculty" placeholder="Faculty Name" onChange={handleChange} required /><br />
        <textarea name="comments" placeholder="Comments" onChange={handleChange} /><br />
        <input name="rating" type="number" min="1" max="5" onChange={handleChange} required /><br />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default StudentPage;