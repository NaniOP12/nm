import express from 'express';
import Feedback from '../models/Feedback.js';
const router = express.Router();

const ADMIN_USERNAME = 'admin';
const ADMIN_PASSWORD = 'admin123';

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    res.json({ success: true });
  } else {
    res.status(401).json({ error: 'Invalid credentials' });
  }
});

router.get('/feedbacks', async (req, res) => {
  const { course, faculty } = req.query;
  const filter = {};
  if (course) filter.course = course;
  if (faculty) filter.faculty = faculty;

  try {
    const feedbacks = await Feedback.find(filter);
    res.json(feedbacks);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching feedbacks' });
  }
});

export default router;