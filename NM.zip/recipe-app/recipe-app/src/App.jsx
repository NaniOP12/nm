import React, { useEffect, useState } from "react";
import axios from "axios";
import "./App.css";

function App() {
  const [recipes, setRecipes] = useState([]);
  const [search, setSearch] = useState("");
  const [selectedRecipe, setSelectedRecipe] = useState(null);
  const [newRecipe, setNewRecipe] = useState({ name: "", ingredients: "", instructions: "" });

  useEffect(() => {
    fetchRecipes();
  }, []);

  const fetchRecipes = async () => {
    const res = await axios.get("http://localhost:5000/recipes");
    setRecipes(res.data);
  };

  const handleSearch = async () => {
    if (search.trim() === "") return;
    try {
      const res = await axios.get(`http://localhost:5000/recipes/${search}`);
      setSelectedRecipe(res.data);
    } catch (error) {
      alert("Recipe not found");
    }
  };

  const handleAddRecipe = async () => {
    const { name, ingredients, instructions } = newRecipe;
    if (!name || !ingredients || !instructions) return alert("Fill all fields");
    await axios.post("http://localhost:5000/recipes", newRecipe);
    setNewRecipe({ name: "", ingredients: "", instructions: "" });
    fetchRecipes();
  };

  return (
    <div className="App">
      <h1>🍽️ Recipe App</h1>

      <div>
        <input
          type="text"
          placeholder="Search dish..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <button onClick={handleSearch}>Search</button>
      </div>

      <h2>All Recipes</h2>
      <ul>
        {recipes.map((recipe) => (
          <li key={recipe._id} onClick={() => setSelectedRecipe(recipe)}>
            {recipe.name}
          </li>
        ))}
      </ul>

      {selectedRecipe && (
        <div className="recipe-details">
          <h3>{selectedRecipe.name}</h3>
          <p><strong>Ingredients:</strong> {selectedRecipe.ingredients}</p>
          <p><strong>Instructions:</strong> {selectedRecipe.instructions}</p>
        </div>
      )}

      <h2>Add New Recipe</h2>
      <input
        placeholder="Name"
        value={newRecipe.name}
        onChange={(e) => setNewRecipe({ ...newRecipe, name: e.target.value })}
        class="new-recipe" />
      <input
        placeholder="Ingredients"
        value={newRecipe.ingredients}
        onChange={(e) => setNewRecipe({ ...newRecipe, ingredients: e.target.value })}
        class="new-recipe" />
      <input
        placeholder="Instructions"
        value={newRecipe.instructions}
        onChange={(e) => setNewRecipe({ ...newRecipe, instructions: e.target.value })}
        class="new-recipe" />
      <button onClick={handleAddRecipe}>Add Recipe</button>
    </div>
  );
}

export default App;
