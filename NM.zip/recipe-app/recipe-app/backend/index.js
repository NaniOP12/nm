const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://localhost:27017/recipeDB", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

const recipeSchema = new mongoose.Schema({
    name: String,
    ingredients: String,
    instructions: String,
});

const Recipe = mongoose.model("Recipe", recipeSchema);

// Get all recipes
app.get("/recipes", async (req, res) => {
    const recipes = await Recipe.find();
    res.json(recipes);
});

// Get recipe by name (case-insensitive)
app.get("/recipes/:name", async (req, res) => {
    const recipe = await Recipe.findOne({ name: { $regex: req.params.name, $options: 'i' } });
    if (recipe) res.json(recipe);
    else res.status(404).json({ error: "Recipe not found" });
});

// Add new recipe
app.post("/recipes", async (req, res) => {
    const { name, ingredients, instructions } = req.body;
    const recipe = new Recipe({ name, ingredients, instructions });
    await recipe.save();
    res.json({ message: "Recipe added" });
});

app.listen(5000, () => console.log("Server running on http://localhost:5000"));
