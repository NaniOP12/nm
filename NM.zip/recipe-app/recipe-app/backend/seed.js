const mongoose = require("mongoose");

mongoose.connect("mongodb://localhost:27017/recipeDB", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

const recipeSchema = new mongoose.Schema({
    name: String,
    ingredients: String,
    instructions: String,
});

const Recipe = mongoose.model("Recipe", recipeSchema);

const sampleRecipes = [
    {
        name: "Spaghetti Bolognese",
        ingredients: "Spaghetti, ground beef, tomato sauce, onion, garlic, herbs",
        instructions: "Cook pasta. Sauté onion and garlic. Add beef, cook. Mix with sauce and herbs.",
    },
    {
        name: "Chicken Curry",
        ingredients: "Chicken, curry powder, coconut milk, onion, garlic, ginger",
        instructions: "Sauté spices and aromatics. Add chicken. Pour coconut milk and simmer.",
    },
    {
        name: "Grilled Cheese Sandwich",
        ingredients: "Bread, cheese, butter",
        instructions: "Butter bread, place cheese between slices, and grill until golden brown.",
    },
    {
        name: "Pancakes",
        ingredients: "Flour, milk, eggs, sugar, baking powder",
        instructions: "Mix ingredients. Pour batter into pan. Flip and cook both sides.",
    },
    {
        name: "Vegetable Stir Fry",
        ingredients: "Broccoli, bell peppers, soy sauce, garlic, oil",
        instructions: "Heat oil, add garlic, add vegetables, stir fry and add soy sauce.",
    },
    {
        name: "Tomato Soup",
        ingredients: "Tomatoes, onion, garlic, broth, cream",
        instructions: "Sauté aromatics, add tomatoes and broth, blend, and add cream.",
    },
    {
        name: "Omelette",
        ingredients: "Eggs, salt, pepper, cheese, vegetables",
        instructions: "Beat eggs, pour in pan, add fillings, cook until set.",
    },
    {
        name: "French Toast",
        ingredients: "Bread, eggs, milk, cinnamon, sugar",
        instructions: "Dip bread in egg mixture and cook in pan until golden.",
    },
    {
        name: "Caesar Salad",
        ingredients: "Lettuce, croutons, Caesar dressing, Parmesan cheese",
        instructions: "Mix lettuce with dressing, top with croutons and cheese.",
    },
    {
        name: "Fried Rice",
        ingredients: "Rice, soy sauce, egg, vegetables, onion",
        instructions: "Scramble egg, stir fry vegetables, add rice and soy sauce.",
    },
    {
        name: "Beef Tacos",
        ingredients: "Ground beef, taco shells, lettuce, tomato, cheese, salsa",
        instructions: "Cook beef with spices. Fill shells with beef and toppings.",
    },
    {
        name: "Mac and Cheese",
        ingredients: "Macaroni, cheese, milk, butter, flour",
        instructions: "Cook pasta, make cheese sauce, mix and bake.",
    },
    {
        name: "Banana Smoothie",
        ingredients: "Banana, milk, honey, ice",
        instructions: "Blend all ingredients until smooth.",
    },
    {
        name: "Scrambled Eggs",
        ingredients: "Eggs, milk, butter, salt, pepper",
        instructions: "Whisk eggs, cook slowly in buttered pan, stir gently.",
    },
    {
        name: "Biryani",
        ingredients: "Rice, meat or vegetables, spices, yogurt, onions",
        instructions: "Layer cooked rice and spiced meat/veg, cook together on low heat.",
    },
    {
        name: "Chole Masala",
        ingredients: "Chickpeas, tomato, onion, masala spices",
        instructions: "Cook onion-tomato masala, add chickpeas, simmer until thick.",
    },
    {
        name: "Butter Chicken",
        ingredients: "Chicken, butter, cream, tomato sauce, spices",
        instructions: "Cook marinated chicken, add tomato-cream sauce and simmer.",
    },
    {
        name: "Dosa",
        ingredients: "Dosa batter, oil, chutney",
        instructions: "Spread batter on pan, cook both sides, serve with chutney.",
    },
    {
        name: "Veg Pulao",
        ingredients: "Rice, vegetables, whole spices",
        instructions: "Cook rice with sautéed vegetables and spices.",
    },
    {
        name: "Rajma",
        ingredients: "Kidney beans, onion, tomato, spices",
        instructions: "Cook beans with masala gravy and simmer well.",
    },
];

const insertRecipes = async () => {
    await Recipe.deleteMany(); // Clear old data (optional)
    await Recipe.insertMany(sampleRecipes);
    console.log("Sample recipes inserted");
    mongoose.connection.close();
};

insertRecipes();
