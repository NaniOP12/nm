import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContactItem from '../contacts/ContactItem';
import './Home.css';

const Home = () => {
const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState();
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchContacts = async () => {
      const token = localStorage.getItem('token');
      try {
        const res = await axios.get('http://localhost:3000/contact', {
          headers: { 'Authorization': token },
        });
        setContacts(res.data.contacts);
      } catch (err) {
        setError('Failed to load contacts');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchContacts();
  }, []);

  const handleDelete = async (id) => {
    const token = localStorage.getItem('token');
    try {
      console.log(id);
      await axios.delete(`http://localhost:3000/contact/${id}`, {
        headers: { 'Authorization': token },
      });
      setContacts(contacts.filter((contact) => contact._id !== id));
    } catch (err) {
      console.log(token)
      alert('Failed to delete contact');
    }
  };

  const [ addData, setAddData ] = useState({
    name:"",
    email:"",
    mobile: ""
  })

  const onAddChange = (e) => {
    setAddData({ ...addData, [e.target.name]: e.target.value });
  };

  const handleAdd = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    try {
      await axios.post(`http://localhost:3000/contact`, addData, {
        headers: { 'Authorization': token },
      });

      window.alert("Contact Added Successfully");
      window.location.reload();
      
    } catch (err) {
      setError(err.response?.data?.msg || 'Failed to update contact');
    }
  };

  return (
    <div className="home-container">
      <h2> Add Contacts : </h2>
      <form onSubmit={handleAdd} className="edit-form" style={{marginBottom: "2rem"}}>
          <div style={{display: "flex", flexDirection: "row", gap:"1rem"}}>
          <input
            type="text"
            name="name"
            value={addData.name}
            onChange={onAddChange}
            placeholder="Name"
            required
          />
          <input
            type="email"
            name="email"
            value={addData.email}
            onChange={onAddChange}
            placeholder="Email"
            required
          />
          <input
            type="text"
            name="mobile"
            value={addData.phone}
            onChange={onAddChange}
            placeholder="Phone"
          />
          </div>
          <div className="form-actions">
            <button type="submit" className="btn-save" style={{margin: "auto"}}>Save</button>
          </div>
        </form>


      <h2>Your Contacts</h2>

      {loading ? (
        <p>Loading contacts...</p>
      ) : error ? (
        <p className="error">{error}</p>
      ) : contacts.length === 0 ? (
        <p>No contacts found. Add some!</p>
      ) : (
        <div className="contact-grid">
          {contacts.map((contact) => (
            <ContactItem key={contact._id} contact={contact} onDelete={handleDelete} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Home;