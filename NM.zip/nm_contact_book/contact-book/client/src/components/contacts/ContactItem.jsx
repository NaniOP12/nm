import React, { useState } from 'react';
import axios from 'axios';
import './ContactItem.css';

const ContactItem = ({ contact, onDelete }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState(contact);
  const [error, setError] = useState('');

  const { name, email, mobile} = formData;

  const onChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const toggleEdit = () => {
    setIsEditing(!isEditing);
    setError('');
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    try {
      await axios.put(`http://localhost:3000/contact`, {...formData, id:contact._id}, {
        headers: { 'Authorization': token },
      });
      setIsEditing(false);
    } catch (err) {
      setError(err.response?.data?.msg || 'Failed to update contact');
    }
  };

  const deleteContact = () => {
    if (window.confirm('Are you sure? This cannot be undone.')) {
      onDelete(contact._id);
    }
  };

  return (
    <div className="contact-card">
      {error && <p className="error-message">{error}</p>}
      {isEditing ? (
        <form onSubmit={handleUpdate} className="edit-form">
          <div style={{display: "flex", flexDirection: "row", gap:"1rem"}}>
          <input
            type="text"
            name="name"
            value={name}
            onChange={onChange}
            placeholder="Name"
            required
          />
          <input
            type="email"
            name="email"
            value={email}
            onChange={onChange}
            placeholder="Email"
            required
          />
          <input
            type="text"
            name="mobile"
            value={mobile}
            onChange={onChange}
            placeholder="Phone"
          />
          </div>

          <div className="form-actions">
            <button type="submit" className="btn-save">Save</button>
            <button type="button" onClick={toggleEdit} className="btn-cancel">Cancel</button>
          </div>
        </form>
      ) : (
        <div className='cont-long'>
          <h3 className='name-cont'>{name}</h3>
          <p><strong>Email:</strong> {email}</p>
          {mobile && <p><strong>Phone:</strong> {mobile}</p>}
          <div className="contact-actions">
            <button onClick={toggleEdit} className="btn-edit">Edit</button>
            <button onClick={deleteContact} className="btn-delete">Delete</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ContactItem;