import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Login.css'; // Reusing same styling for auth forms

const Register = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    password2: ''
  });

  const navigate = useNavigate();
  const { email, password, password2 } = formData;

  const onChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();

    if (password !== password2) {
      alert('Passwords do not match');
      return;
    }

    try {
      const res = await axios.post('http://localhost:3000/auth/register', { username:email, password });

      console.log('Registration successful:', res.data);

      if (res.data.token) {
        localStorage.setItem('token', res.data.token);
        navigate('/home'); // ✅ Redirect directly to Home page
      } else {
        alert('Registration successful, but no token received. Please log in.');
        navigate('/login');
      }
    } catch (err) {
      console.error('Registration failed:', err.response?.data || err.message);
      const errorMessage = err.response?.data?.msg || 'Registration failed. Try again.';
      alert(errorMessage);
    }
  };

  return (
    <div className="auth-container">
      <h2>Create an Account</h2>
      <form className="auth-form" onSubmit={onSubmit}>

        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            name="email"
            value={email}
            onChange={onChange}
            placeholder="you@example.com"
            required
          />
        </div>

        <div className="form-group">
          <label>Password</label>
          <input
            type="password"
            name="password"
            value={password}
            onChange={onChange}
            minLength="6"
            placeholder="••••••••"
            required
          />
        </div>

        <div className="form-group">
          <label>Confirm Password</label>
          <input
            type="password"
            name="password2"
            value={password2}
            onChange={onChange}
            minLength="6"
            placeholder="••••••••"
            required
          />
        </div>

        <button type="submit" className="btn-submit">Register</button>
      </form>

      <p className="auth-link">
        Already have an account? <a href="/login">Login here</a>
      </p>
    </div>
  );
};

export default Register;