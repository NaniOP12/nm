import { Router } from "express";

import { getContact, addContact, deleteContact, updateContact } from "../controllers/contactController.js";
import User from "../models/User.js";

const contactRouter = Router();

contactRouter.use( async (req, res, next) => {
    
    if( req.headers.authorization ) {
        try {
            let token = req.headers.authorization;
            
            req.user = await User.findOne( { username: token});
            console.log( token );
            next();
        } catch ( e ) {
            res.json( {ok: false, message: e.message});
        }
    } else {
        console.log(req.headers.authorization);
        res.status(401).json( {ok:false, message: "User Authentication Required"});
    }

})

contactRouter.get("/", getContact);
contactRouter.post("/", addContact);
contactRouter.delete("/:id", deleteContact);
contactRouter.put("/", updateContact);

export default contactRouter;