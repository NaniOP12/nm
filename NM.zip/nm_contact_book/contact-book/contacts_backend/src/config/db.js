import mongoose from "mongoose";

const connectDB = async () => {
    try {
        mongoose.connect( process.env.DB_URI );
        console.log("DB Connected Succssfully");
    } catch ( e ) {
        console.log( e);
        process.exit(1);
    }
}

export default connectDB;