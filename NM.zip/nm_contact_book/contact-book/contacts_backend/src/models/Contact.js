import mongoose from "mongoose";

const contactSchema = mongoose.Schema({
    "username": String,
    "name": String,
    "email": String,
    "mobile": String,
    "created_at": Date
});

const Contact = mongoose.model("Contact", contactSchema);

export default Contact;