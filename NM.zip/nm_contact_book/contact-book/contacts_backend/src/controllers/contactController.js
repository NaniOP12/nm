import Contact from "../models/Contact.js";

async function getContact(req, res) {

    try {
        const contacts = await Contact.find();

        res.json( {ok:true, contacts: contacts})
    } catch (e) {
        res.json( {ok:false, message:e.message});
    }
}

async function addContact(req, res) {
    const {name, email, mobile} = req.body;

    try {
        const contact = new Contact( { 
            username: req.user.username,
            name: name,
            email: email,
            mobile: mobile,
            created_at: Date.now()
        });

        await contact.save();
        res.json( {ok:true, message:"Contact Saved Successfully"} );
    } catch ( e ) {
        
        res.json( { ok:false, message: e.message});
    }
}

async function deleteContact(req, res) {
    const { id } = req.params;

    console.log(req.params);

    try {
        const deletedContact = await Contact.findByIdAndDelete(id);

        if (!deletedContact) {
            return res.json({ ok: false, message: "Contact not found" });
        }

        res.json({ ok: true, message: "Contact Deleted Successfully" });
    } catch (e) {
        res.json({ ok: false, message: e.message });
    }
}

async function updateContact(req, res) {
    const { id } = req.body;
    const { name, email, mobile } = req.body;

    try {
        const updatedContact = await Contact.findByIdAndUpdate(
            id,
            {
                name,
                email,
                mobile,
                updated_at: Date.now()
            },
            { new: true } // Return the updated document
        );

        if (!updatedContact) {
            return res.json({ ok: false, message: "Contact not found" });
        }

        res.json({ ok: true, message: "Contact Updated Successfully", contact: updatedContact });
    } catch (e) {
        res.json({ ok: false, message: e.message });
    }
}

export { getContact, addContact, deleteContact, updateContact};