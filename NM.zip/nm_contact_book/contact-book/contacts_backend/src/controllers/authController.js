import User from "../models/User.js";


async function registerUser( req, res) {
    const { username, password } = req.body;

    try {
        const user = new User( {username, password});
        await user.save();
        
        res.json( {"ok": true, "user": user});
    } catch(e) {
        console.log(e);
        res.json( { "ok": false, "error": e.message})
    }
}

async function loginUser( req, res) {
    const { username, password } = req.body;

    try {
        const user = await User.findOne( { username });

        if( password === user.password ) {
            res.json( {"ok": true, "token": username, "message": "User Login Successful"});
        } else {
            res.json( {"ok": false, "message": "Invalid Credentials"});
        }
    } catch ( e) {
        console.log(e);
        res.json({"ok": false, "message": e.message })
    }
}

export { registerUser, loginUser };