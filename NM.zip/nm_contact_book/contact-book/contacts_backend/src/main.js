import "dotenv/config"
import express from "express";
import cors from "cors";

import connectDB from "./config/db.js";
import authRouter from "./routes/authRoute.js";
import contactRouter from "./routes/contactRoute.js";

const app = express()
const PORT = process.env.PORT || 3000

connectDB();

app.use(cors({
    origin: "*"
}));
app.use( express.json() );
app.use( express.urlencoded({extended: true}));


app.use( (req, _, next) => {
    console.log(`Request Received : ${req.method} - ${req.url}`);
    next();
})


app.use("/auth", authRouter);
app.use("/contact", contactRouter);


app.get("/hello-world", (req, res) => {
    res.end("Hello World");
})


app.listen(PORT, () => console.log(`Server started listening on ${PORT}`));