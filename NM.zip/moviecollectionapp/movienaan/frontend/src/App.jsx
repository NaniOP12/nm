import { useEffect, useState } from "react";
import axios from "axios";
import MovieForm from "./components/MovieForm";
import MovieList from "./components/MovieList";

function App() {
  const [movies, setMovies] = useState([]);
  const [filterInput, setFilterInput] = useState("");
  const [filter, setFilter] = useState("");

  const fetchMovies = async () => {
    const url = `http://localhost:5000/api/movies${
      filter ? `?genre=${filter}` : ""
    }`;
    const res = await axios.get(url);
    setMovies(res.data);
  };

  useEffect(() => {
    fetchMovies();
  }, [filter]);

  return (
    <div className="container">
      <h1>Movie Collection</h1>
      <MovieForm onAction={fetchMovies} />

      <div>
        <label>
          Filter by genre:
          <input
            type="text"
            value={filterInput}
            onChange={(e) => setFilterInput(e.target.value)}
          />
        </label>
        <button onClick={() => setFilter(filterInput)}>Apply</button>
        <button
          onClick={() => {
            setFilter("");
            setFilterInput("");
          }}
        >
          Clear
        </button>
      </div>

      <MovieList movies={movies} onAction={fetchMovies} />
    </div>
  );
}

export default App;
