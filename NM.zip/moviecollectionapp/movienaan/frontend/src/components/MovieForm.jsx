import { useState, useEffect } from "react";
import axios from "axios";

function MovieForm({ movie, onAction }) {
  const [title, setTitle] = useState("");
  const [genre, setGenre] = useState("");
  const [rating, setRating] = useState("");

  useEffect(() => {
    if (movie) {
      setTitle(movie.title);
      setGenre(movie.genre);
      setRating(movie.rating);
    }
  }, [movie]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const movieData = { title, genre, rating };

    if (movie) {
      await axios.put(
        `http://localhost:5000/api/movies/${movie._id}`,
        movieData
      );
    } else {
      await axios.post("http://localhost:5000/api/movies", movieData);
    }

    setTitle("");
    setGenre("");
    setRating("");
    onAction();
  };

  return (
    <form onSubmit={handleSubmit}>
      <h3>{movie ? "Edit Movie" : "Add Movie"}</h3>
      <input
        type="text"
        placeholder="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        required
      />
      <input
        type="text"
        placeholder="Genre"
        value={genre}
        onChange={(e) => setGenre(e.target.value)}
        required
      />
      <input
        type="number"
        placeholder="Rating"
        value={rating}
        onChange={(e) => setRating(e.target.value)}
        required
      />
      <button type="submit">{movie ? "Update" : "Add"}</button>
    </form>
  );
}

export default MovieForm;
