import { useState } from "react";
import axios from "axios";
import MovieForm from "./MovieForm";

function MovieList({ movies, onAction }) {
  const [editingMovie, setEditingMovie] = useState(null);

  const handleDelete = async (id) => {
    await axios.delete(`http://localhost:5000/api/movies/${id}`);
    onAction(); // Refresh list
  };

  const handleEdit = (movie) => {
    setEditingMovie(movie);
  };

  const cancelEdit = () => {
    setEditingMovie(null);
  };

  return (
    <div>
      {editingMovie && (
        <MovieForm
          movie={editingMovie}
          onAction={() => {
            onAction();
            cancelEdit();
          }}
        />
      )}
      <ul>
        {movies.map((movie) => (
          <li key={movie._id}>
            <strong>{movie.title}</strong> ({movie.genre}) - {movie.rating}
            <button onClick={() => handleEdit(movie)}>Edit</button>
            <button onClick={() => handleDelete(movie._id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default MovieList;
