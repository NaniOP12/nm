import axios from "axios";

export default function MovieList({ movies, onAction }) {
  const deleteMovie = async (id) => {
    await axios.delete(`http://localhost:5000/api/movies/${id}`);
    onAction();
  };

  return (
    <ul>
      {movies.map((movie) => (
        <li key={movie._id}>
          <strong>{movie.title}</strong> - {movie.genre} - Rating:{" "}
          {movie.rating}
          <button onClick={() => deleteMovie(movie._id)}>Delete</button>
        </li>
      ))}
    </ul>
  );
}
