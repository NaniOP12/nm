import { useState } from "react";
import axios from "axios";

export default function MovieForm({ onAction }) {
  const [movie, setMovie] = useState({ title: "", genre: "", rating: "" });

  const handleChange = (e) => {
    setMovie({ ...movie, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:5000/api/movies", movie);
    setMovie({ title: "", genre: "", rating: "" });
    onAction();
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        name="title"
        placeholder="Title"
        onChange={handleChange}
        value={movie.title}
        required
      />
      <input
        name="genre"
        placeholder="Genre"
        onChange={handleChange}
        value={movie.genre}
      />
      <input
        name="rating"
        placeholder="Rating"
        onChange={handleChange}
        value={movie.rating}
        type="number"
      />
      <button type="submit">Add Movie</button>
    </form>
  );
}
