import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import movieRoutes from "./routes/movies.js"; // ✅ Your movie routes

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Optional test route
app.get("/", (req, res) => {
  res.send("🎬 Movie API is running!");
});

// Use the routes
app.use("/api/movies", movieRoutes);

// Connect to MongoDB and start server
mongoose
  .connect("mongodb://localhost:27017/moviesdb", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    app.listen(PORT, () => {
      console.log(`✅ Server running on http://localhost:${PORT}`);
    });
  })
  .catch((error) => console.error("❌ MongoDB connection failed:", error));
