import Movie from "../models/Movie.js";

export const getMovies = async (req, res) => {
  const { genre } = req.query;
  const filter = genre ? { genre } : {};
  const movies = await Movie.find(filter);
  res.json(movies);
};

export const addMovie = async (req, res) => {
  const newMovie = new Movie(req.body);
  await newMovie.save();
  res.json(newMovie);
};

export const updateMovie = async (req, res) => {
  const movie = await Movie.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });
  res.json(movie);
};

export const deleteMovie = async (req, res) => {
  await Movie.findByIdAndDelete(req.params.id);
  res.json({ message: "Movie deleted" });
};
