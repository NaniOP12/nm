const Customer = require("../models/customer");
const Transaction = require("../models/Transaction");

exports.performTransaction = async (req, res) => {
  const { customerId, type, amount } = req.body;
  const customer = await Customer.findById(customerId);

  if (!customer) return res.status(404).json({ error: "Customer not found" });

  if (type === "withdraw" && customer.balance < amount) {
    return res.status(400).json({ error: "Insufficient balance" });
  }

  customer.balance += type === "deposit" ? amount : -amount;
  await customer.save();

  const transaction = new Transaction({ customerId, type, amount });
  await transaction.save();

  res.json({ customer, transaction });
};

exports.getTransactionHistory = async (req, res) => {
  const { customerId } = req.params;
  const history = await Transaction.find({ customerId });
  res.json(history);
};
