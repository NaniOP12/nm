const Customer = require("../models/customer");

exports.addCustomer = async (req, res) => {
  const { name, balance } = req.body;
  const customer = new Customer({ name, balance });
  await customer.save();
  res.json(customer);
};

exports.getCustomers = async (req, res) => {
  const customers = await Customer.find();
  res.json(customers);
};

exports.updateBalance = async (req, res) => {
  const { id } = req.params;
  const { balance } = req.body;
  const updated = await Customer.findByIdAndUpdate(
    id,
    { balance },
    { new: true }
  );
  res.json(updated);
};
