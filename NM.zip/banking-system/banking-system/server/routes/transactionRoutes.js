const express = require("express");
const {
  performTransaction,
  getTransactionHistory,
} = require("../controllers/transactionController");
const router = express.Router();

router.post("/", performTransaction);
router.get("/:customerId", getTransactionHistory);

module.exports = router;
