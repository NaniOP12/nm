const express = require("express");
const {
  addCustomer,
  getCustomers,
  updateBalance,
} = require("../controllers/customerController");
const router = express.Router();

router.post("/", addCustomer);
router.get("/", getCustomers);
router.put("/:id", updateBalance);

module.exports = router;
