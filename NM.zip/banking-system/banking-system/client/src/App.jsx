import AddCustomer from "./components/AddCustomer";
import ViewCustomers from "./components/ViewCustomers";
import TransactionForm from "./components/TransactionForm";
import TransactionHistory from "./components/TransactionHistory";

function App() {
  return (
    <div style={{ padding: "20px" }}>
      <h1>🏦 Simple Banking System</h1>
      <AddCustomer />
      <hr />
      <ViewCustomers />
      <hr />
      <TransactionForm />
      <hr />
      <TransactionHistory />
    </div>
  );
}

export default App;
