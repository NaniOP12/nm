import { useEffect, useState } from "react";
import API from "../api";

function TransactionForm() {
  const [customers, setCustomers] = useState([]);
  const [customerId, setCustomerId] = useState("");
  const [type, setType] = useState("deposit");
  const [amount, setAmount] = useState("");

  useEffect(() => {
    API.get("/customers").then((res) => {
      setCustomers(res.data);
      if (res.data.length > 0) setCustomerId(res.data[0]._id);
    });
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!amount || isNaN(amount) || amount <= 0)
      return alert("Enter valid amount");

    await API.post("/transactions", {
      customerId,
      type,
      amount: Number(amount),
    });

    setAmount("");
    alert(`${type} ₹${amount} successful`);
  };

  return (
    <form onSubmit={handleSubmit}>
      <h3>Transaction</h3>
      <select
        value={customerId}
        onChange={(e) => setCustomerId(e.target.value)}
      >
        {customers.map((c) => (
          <option key={c._id} value={c._id}>
            {c.name}
          </option>
        ))}
      </select>
      <select value={type} onChange={(e) => setType(e.target.value)}>
        <option value="deposit">Deposit</option>
        <option value="withdraw">Withdraw</option>
      </select>
      <input
        type="number"
        placeholder="Amount"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
      />
      <button type="submit">Submit</button>
    </form>
  );
}

export default TransactionForm;
