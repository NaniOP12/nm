import { useEffect, useState } from "react";
import API from "../api";

function TransactionHistory() {
  const [customers, setCustomers] = useState([]);
  const [customerId, setCustomerId] = useState("");
  const [history, setHistory] = useState([]);

  useEffect(() => {
    API.get("/customers").then((res) => {
      setCustomers(res.data);
      if (res.data.length > 0) {
        const firstId = res.data[0]._id;
        setCustomerId(firstId);
        fetchHistory(firstId);
      }
    });
  }, []);

  const fetchHistory = async (id) => {
    const res = await API.get(`/transactions/${id}`);
    setHistory(res.data);
  };

  const handleChange = (e) => {
    const id = e.target.value;
    setCustomerId(id);
    fetchHistory(id);
  };

  return (
    <div>
      <h3>Transaction History</h3>
      <select value={customerId} onChange={handleChange}>
        {customers.map((c) => (
          <option key={c._id} value={c._id}>
            {c.name}
          </option>
        ))}
      </select>
      <ul>
        {history.map((tx) => (
          <li key={tx._id}>
            [{new Date(tx.date).toLocaleString()}] {tx.type.toUpperCase()} ₹
            {tx.amount}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default TransactionHistory;
