import { useEffect, useState } from "react";
import API from "../api";

function ViewCustomers() {
  const [customers, setCustomers] = useState([]);

  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = async () => {
    const res = await API.get("/customers");
    setCustomers(res.data);
  };

  return (
    <div>
      <h3>Customer Records</h3>
      <table border="1" cellPadding="8">
        <thead>
          <tr>
            <th>Name</th>
            <th>Balance (₹)</th>
          </tr>
        </thead>
        <tbody>
          {customers.map((c) => (
            <tr key={c._id}>
              <td>{c.name}</td>
              <td>{c.balance}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ViewCustomers;
