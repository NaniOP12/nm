import { useState } from "react";
import API from "../api";

function AddCustomer() {
  const [name, setName] = useState("");
  const [balance, setBalance] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name || !balance) return alert("Please fill both fields");
    await API.post("/customers", { name, balance });
    setName("");
    setBalance("");
    alert("Customer added!");
  };

  return (
    <form onSubmit={handleSubmit}>
      <h3>Add Customer</h3>
      <input
        type="text"
        placeholder="Customer Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <input
        type="number"
        placeholder="Initial Balance"
        value={balance}
        onChange={(e) => setBalance(e.target.value)}
      />
      <button type="submit">Add</button>
    </form>
  );
}

export default AddCustomer;
