module.exports = function(io) {
    const express = require('express');
    const bcrypt = require('bcryptjs');
    const jwt = require('jsonwebtoken');
    const Room = require('../models/Room');
    const User = require('../models/User');
    const router = express.Router();
  
    const JWT_SECRET = process.env.JWT_SECRET;
  
    function authMiddleware(req, res, next) {
      const token = req.headers.authorization?.split(" ")[1];
      if (!token) return res.status(401).json({ msg: "No token provided" });
  
      try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
      } catch {
        res.status(401).json({ msg: "Invalid token" });
      }
    }
  
    // Create Room
    router.post('/create', authMiddleware, async (req, res) => {
      const { name, password } = req.body;
      const existingRoom = await Room.findOne({ name });
      if (existingRoom) return res.status(400).json({ msg: "Room already exists" });
  
      const hashedPassword = await bcrypt.hash(password, 10);
      const newRoom = new Room({
        name,
        password: hashedPassword,
        members: [req.user.id]
      });
  
      await newRoom.save();
  
      const populated = await Room.findById(newRoom._id).populate('members', 'username');
      io.to(newRoom._id.toString()).emit('members_update', populated.members);
  
      res.json({ msg: 'Room created', roomId: newRoom._id });
    });
  
    // Join Room
    router.post('/join', authMiddleware, async (req, res) => {
      const { name, password } = req.body;
      const room = await Room.findOne({ name });
      if (!room) return res.status(404).json({ msg: 'Room not found' });
  
      const match = await bcrypt.compare(password, room.password);
      if (!match) return res.status(401).json({ msg: 'Incorrect room password' });
  
      if (!room.members.includes(req.user.id)) {
        room.members.push(req.user.id);
        await room.save();
  
        const updatedRoom = await Room.findById(room._id).populate('members', 'username');
        io.to(room._id.toString()).emit('members_update', updatedRoom.members);
      }
  
      res.json({ msg: 'Joined room', roomId: room._id });
    });
  
    // Leave Room
    router.post('/leave/:roomId', authMiddleware, async (req, res) => {
      const room = await Room.findById(req.params.roomId);
      if (!room) return res.status(404).json({ msg: 'Room not found' });
  
      room.members = room.members.filter(
        (memberId) => memberId.toString() !== req.user.id
      );
      await room.save();
  
      const updatedRoom = await Room.findById(room._id).populate('members', 'username');
      io.to(room._id.toString()).emit('members_update', updatedRoom.members);
  
      res.json({ msg: 'Left the room' });
    });
  
    // Get room members
    router.get('/members/:roomId', authMiddleware, async (req, res) => {
    try {
        const room = await Room.findById(req.params.roomId).populate('members', 'username');
        if (!room) return res.status(404).json({ msg: 'Room not found' });

        res.json({ members: room.members });
    } catch (err) {
        console.error(err);
        res.status(500).json({ msg: 'Server error' });
    }
    });

    const Message = require('../models/Message');

    // Get previous messages of a room
    router.get('/messages/:roomId', authMiddleware, async (req, res) => {
    try {
        const messages = await Message.find({ room: req.params.roomId })
        .sort({ timestamp: 1 }) // oldest first
        .populate('sender', 'username');
        
        res.json(messages);
    } catch (err) {
        console.error(err);
        res.status(500).json({ msg: 'Could not load messages' });
    }
    });


    return router;
  };
  