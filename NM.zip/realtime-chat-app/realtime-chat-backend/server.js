const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Message = require('./models/Message'); // Chat model

dotenv.config();

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: 'http://localhost:5173', methods: ['GET', 'POST'] }
});

// Middleware
app.use(cors());
app.use(express.json());

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("✅ MongoDB connected"))
  .catch(console.error);

// Routes
const roomRoutes = require('./routes/room')(io); // inject io
app.use('/api/room', roomRoutes);
app.use('/api/auth', require('./routes/auth'));

// Socket.IO connection
io.on('connection', (socket) => {
  console.log(`🔌 Socket connected: ${socket.id}`);

  // User joins room
  socket.on('join_room', async ({ roomId, username }) => {
    socket.join(roomId);
    console.log(`✅ ${username} joined room ${roomId}`);

    // Broadcast system message
    io.to(roomId).emit('new_message', {
      sender: { username: 'Server' },
      text: `${username} joined the room.`,
      type: 'system',
      timestamp: new Date()
    });
  });

  // User leaves room
  socket.on('leave_room', async ({ roomId, username }) => {
    socket.leave(roomId);
    console.log(`❌ ${username} left room ${roomId}`);

    // Broadcast system message
    io.to(roomId).emit('new_message', {
      sender: { username: 'Server' },
      text: `${username} left the room.`,
      type: 'system',
      timestamp: new Date()
    });
  });

  // Handle user message
  socket.on('send_message', async ({ roomId, userId, text }) => {
    try {
      const message = await Message.create({
        room: roomId,
        sender: userId,
        text
      });

      const populated = await message.populate('sender', 'username');
      io.to(roomId).emit('new_message', {
        ...populated.toObject(),
        type: 'user',
        timestamp: new Date()
      });
    } catch (err) {
      console.error("💥 Message error:", err.message);
    }
  });
});

// Start server
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
