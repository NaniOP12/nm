import { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { io } from 'socket.io-client';

const socket = io("http://localhost:5000");

const ChatRoom = () => {
  const { roomId } = useParams();
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  const [members, setMembers] = useState([]);
  const [messages, setMessages] = useState([]);
  const [newMsg, setNewMsg] = useState("");
  const [user, setUser] = useState(null);

  const chatEndRef = useRef(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const fetchUser = async () => {
    const res = await axios.get(`http://localhost:5000/api/auth/me`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    setUser(res.data);
  };

  const fetchMembers = async () => {
    const res = await axios.get(`http://localhost:5000/api/room/members/${roomId}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    setMembers(res.data.members);
  };

  const fetchMessages = async () => {
    const res = await axios.get(`http://localhost:5000/api/room/messages/${roomId}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    // Mark them as user messages for consistency
    setMessages(res.data.map(m => ({ ...m, type: 'user' })));
  };

  useEffect(() => {
    fetchUser();
  }, []);

  useEffect(() => {
    if (!user) return;

    fetchMembers();
    fetchMessages();

    socket.emit('join_room', { roomId, username: user.username });

    socket.on('members_update', setMembers);
    socket.on('new_message', (msg) => {
      setMessages(prev => [...prev, msg]);
    });

    return () => {
      socket.emit('leave_room', { roomId, username: user.username });
      socket.off('members_update');
      socket.off('new_message');
    };
  }, [roomId, user]);

  useEffect(scrollToBottom, [messages]);

  const handleSend = () => {
    if (!newMsg.trim()) return;

    socket.emit('send_message', {
      roomId,
      userId: user._id,
      text: newMsg
    });
    setNewMsg('');
  };

  const handleLeave = async () => {
    await axios.post(`http://localhost:5000/api/room/leave/${roomId}`, {}, {
      headers: { Authorization: `Bearer ${token}` },
    });
    navigate('/home');
  };

  return (
    <div style={{ padding: '20px' }}>
      {user && (
        <div style={{ marginBottom: '10px' }}>
          Logged in as: <strong>{user.username}</strong>
        </div>
      )}

      <h2>Chat Room Members</h2>
      <ul>
        {members.map((m) => (
          <li key={m._id}>{m.username}</li>
        ))}
      </ul>

      <h3>Chat</h3>
      <div style={{
        border: '1px solid #ccc',
        padding: 10,
        height: 300,
        overflowY: 'auto',
        marginBottom: '10px'
      }}>
        {messages.map((msg, idx) => (
          <div key={idx} style={{
            textAlign: msg.type === 'system' ? 'center' : 'left',
            fontStyle: msg.type === 'system' ? 'italic' : 'normal',
            color: msg.type === 'system' ? 'gray' : 'black'
          }}>
            {msg.type === 'system' ? (
              <p>🔔 {msg.text}</p>
            ) : (
              <p><strong>{msg.sender.username}:</strong> {msg.text}</p>
            )}
          </div>
        ))}
        <div ref={chatEndRef} />
      </div>

      <input
        type="text"
        value={newMsg}
        onChange={(e) => setNewMsg(e.target.value)}
        placeholder="Type a message..."
      />
      <button onClick={handleSend}>Send</button>
      <br />
      <button onClick={handleLeave}>Leave Group</button>
    </div>
  );
};

export default ChatRoom;
