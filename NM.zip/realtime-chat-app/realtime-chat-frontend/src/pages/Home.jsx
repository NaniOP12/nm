import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  const [createData, setCreateData] = useState({ name: '', password: '' });
  const [joinData, setJoinData] = useState({ name: '', password: '' });

  const handleCreate = async () => {
    try {
      const res = await axios.post('http://localhost:5000/api/room/create', createData, {
        headers: { Authorization: `Bearer ${token}` },
      });
      navigate(`/chat/${res.data.roomId}`);
    } catch (err) {
      alert(err.response?.data?.msg || 'Create failed');
    }
  };

  const handleJoin = async () => {
    try {
      const res = await axios.post('http://localhost:5000/api/room/join', joinData, {
        headers: { Authorization: `Bearer ${token}` },
      });
      navigate(`/chat/${res.data.roomId}`);
    } catch (err) {
      alert(err.response?.data?.msg || 'Join failed');
    }
  };

  return (
    <div>
      <h2>Welcome {localStorage.getItem('username')}</h2>
      
      <div>
        <h3>Create Group</h3>
        <input placeholder="Group Name" onChange={e => setCreateData({ ...createData, name: e.target.value })} />
        <input placeholder="Password" type="password" onChange={e => setCreateData({ ...createData, password: e.target.value })} />
        <button onClick={handleCreate}>Create</button>
      </div>

      <div>
        <h3>Join Group</h3>
        <input placeholder="Group Name" onChange={e => setJoinData({ ...joinData, name: e.target.value })} />
        <input placeholder="Password" type="password" onChange={e => setJoinData({ ...joinData, password: e.target.value })} />
        <button onClick={handleJoin}>Join</button>
      </div>
    </div>
  );
};

export default Home;
