# server side 
..server >> npm install
..server >> node server.js
# display
✅ Connected to MongoDB (local)
🚀 Server running at http://localhost:5000

# client side(React)
..client >> cd client
..client >> npm install
..client >> npm start

# output
🚀 client running at http://localhost:3000

