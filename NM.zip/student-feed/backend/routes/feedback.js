const express = require('express');
const router = express.Router();
const Feedback = require('../models/Feedbacks');

router.post('/', async (req, res) => {
  const newFeedback = new Feedback(req.body);
  await newFeedback.save();
  res.send({ message: 'Feedback submitted' });
});

router.get('/', async (req, res) => {
  const { course, faculty } = req.query;
  let filter = {};
  if (course) filter.course = course;
  if (faculty) filter.faculty = faculty;
  const feedbacks = await Feedback.find(filter);
  res.send(feedbacks);
});

module.exports = router;
