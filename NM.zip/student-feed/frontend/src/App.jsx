import FeedbackForm from './components/FeedbackForm';
import FeedbackList from './components/FeedbackList';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="container mt-4">
      <h2>Student Feedback Form</h2>
      <FeedbackForm />
      <hr />
      <h2>Admin Feedback View</h2>
      <FeedbackList />
    </div>
  );
}

export default App;
