import React, { useEffect, useState } from 'react';
import axios from 'axios';

function FeedbackList() {
  const [feedbacks, setFeedbacks] = useState([]);
  const [filter, setFilter] = useState({ course: '', faculty: '' });

  useEffect(() => {
    fetchFeedback();
  }, [filter]);

  const fetchFeedback = async () => {
    const res = await axios.get('/api/feedback', { params: filter });
    setFeedbacks(res.data);
  };

  const handleChange = e => setFilter({ ...filter, [e.target.name]: e.target.value });

  return (
    <div className="p-4">
      <input name="course" placeholder="Filter by Course" onChange={handleChange} className="form-control mb-2" />
      <input name="faculty" placeholder="Filter by Faculty" onChange={handleChange} className="form-control mb-2" />
      <table className="table table-bordered">
        <thead>
          <tr><th>Name</th><th>Course</th><th>Faculty</th><th>Comments</th><th>Rating</th></tr>
        </thead>
        <tbody>
          {feedbacks.map((fb, i) => (
            <tr key={i}>
              <td>{fb.studentName}</td>
              <td>{fb.course}</td>
              <td>{fb.faculty}</td>
              <td>{fb.comments}</td>
              <td>{fb.rating}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default FeedbackList;
