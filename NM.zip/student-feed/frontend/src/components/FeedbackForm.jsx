import React, { useState } from 'react';
import axios from 'axios';

function FeedbackForm() {
  const [form, setForm] = useState({
    studentName: '',
    course: '',
    faculty: '',
    comments: '',
    rating: 1
  });

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    await axios.post('/api/feedback', form);
    alert('Feedback submitted!');
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 border rounded shadow">
      <input name="studentName" placeholder="Your Name" onChange={handleChange} className="form-control mb-2" required />
      <input name="course" placeholder="Course Name" onChange={handleChange} className="form-control mb-2" required />
      <input name="faculty" placeholder="Faculty Name" onChange={handleChange} className="form-control mb-2" required />
      <textarea name="comments" placeholder="Comments" onChange={handleChange} className="form-control mb-2" />
      <input type="number" name="rating" min="1" max="5" onChange={handleChange} className="form-control mb-2" />
      <button type="submit" className="btn btn-primary">Submit</button>
    </form>
  );
}

export default FeedbackForm;
