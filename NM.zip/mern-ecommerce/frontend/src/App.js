import React, { useEffect, useState } from "react";
import axios from "axios";
import Cart from "./Cart"; // ✅ make sure Cart.js is placed properly in same folder or use ./components/Cart if in components

function App() {
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState({ name: "", price: "", image: "" });
  const [editingId, setEditingId] = useState(null);
  const [cart, setCart] = useState([]);

  const fetchProducts = async () => {
    try {
      const res = await axios.get("http://localhost:5000/products");
      setProducts(res.data);
    } catch (err) {
      console.error("Error fetching products:", err);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingId) {
        await axios.put(`http://localhost:5000/products/${editingId}`, form);
        setEditingId(null);
      } else {
        await axios.post("http://localhost:5000/products", form);
      }
      setForm({ name: "", price: "", image: "" });
      fetchProducts();
    } catch (err) {
      console.error("Error saving product:", err);
    }
  };

  const handleEdit = (product) => {
    setForm(product);
    setEditingId(product._id);
  };

  const handleDelete = async (id) => {
    await axios.delete(`http://localhost:5000/products/${id}`);
    fetchProducts();
  };

  // ✅ Cart Functions
  const handleAddToCart = (product) => {
    const exists = cart.find((item) => item._id === product._id);
    if (!exists) {
      setCart([...cart, { ...product, bought: false }]);
    } else {
      alert("Product already in cart!");
    }
  };

  const handleRemoveFromCart = (id) => {
    setCart(cart.filter((item) => item._id !== id));
  };

  const handleToggleBought = (id) => {
    setCart(
      cart.map((item) =>
        item._id === id ? { ...item, bought: !item.bought } : item
      )
    );
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>🛍️ Mini E-Commerce Site</h2>

      <form onSubmit={handleSubmit} style={{ marginBottom: 20 }}>
        <input
          placeholder="Name"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          required
        />
        <input
          placeholder="Price"
          type="number"
          value={form.price}
          onChange={(e) => setForm({ ...form, price: e.target.value })}
          required
        />
        <input
          placeholder="Image URL"
          value={form.image}
          onChange={(e) => setForm({ ...form, image: e.target.value })}
          required
        />
        <button type="submit">{editingId ? "Update" : "Add"}</button>
      </form>

      <h3>🛒 Products</h3>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 20 }}>
        {products.map((p) => (
          <div
            key={p._id}
            style={{
              border: "1px solid #ccc",
              padding: 10,
              width: 200,
              borderRadius: 5,
            }}
          >
            <img src={p.image} alt={p.name} width="100%" height="150" />
            <h4>{p.name}</h4>
            <p>₹{p.price}</p>
            <button onClick={() => handleAddToCart(p)}>Add to Cart</button>
            <button onClick={() => handleEdit(p)}>Edit</button>
            <button onClick={() => handleDelete(p._id)}>Delete</button>
          </div>
        ))}
      </div>

      {/* ✅ Cart Component */}
      <Cart
        cartItems={cart}
        onRemove={handleRemoveFromCart}
        onToggleBought={handleToggleBought}
      />
    </div>
  );
}

export default App;
