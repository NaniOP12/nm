import React from "react";

const Cart = ({ cartItems, onRemove, onToggleBought }) => {
  return (
    <div>
      <h2>🛒 Cart</h2>
      {cartItems.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <ul>
          {cartItems.map((item) => (
            <li key={item._id} style={{ marginBottom: "10px" }}>
              <strong>{item.name}</strong> - ₹{item.price}
              <span
                style={{
                  marginLeft: "10px",
                  color: item.bought ? "green" : "orange",
                }}
              >
                {item.bought ? "✅ Bought" : "🕓 Pending"}
              </span>
              <div style={{ marginTop: "5px" }}>
                <button
                  onClick={() => onToggleBought(item._id)}
                  style={{ marginRight: "5px" }}
                >
                  {item.bought ? "Mark as Pending" : "Mark as Bought"}
                </button>
                <button
                  onClick={() => onRemove(item._id)}
                  style={{ color: "red" }}
                >
                  Remove
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Cart;
