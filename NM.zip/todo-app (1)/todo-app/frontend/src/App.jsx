import { useEffect, useState } from "react";
import "./App.css"

const API = "http://localhost:5000/api/tasks";

function App() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [priority, setPriority] = useState("Medium");
  const [filter, setFilter] = useState("");
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetchTasks();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  const fetchTasks = async () => {
    try {
      const res = await fetch(`${API}?status=${filter}`);
      const data = await res.json();
      setTasks(data);
    } catch (err) {
      console.error("Fetch error:", err);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch(API, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, dueDate, priority }),
    });
    const newTask = await res.json();
    setTasks((prev) => [...prev, newTask]);
    setTitle("");
    setDueDate("");
    setPriority("Medium");
  };

  const updateTask = async (id, currentStatus) => {
    const newStatus = currentStatus === "pending" ? "completed" : "pending";
    await fetch(`${API}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: newStatus }),
    });
    fetchTasks();
  };

  const deleteTask = async (id) => {
    if (window.confirm("Delete this task?")) {
      await fetch(`${API}/${id}`, { method: "DELETE" });
      fetchTasks();
    }
  };

  const filteredTasks = tasks.filter((task) =>
    task.title.toLowerCase().includes(search.toLowerCase())
  );

  const pending = tasks.filter((t) => t.status === "pending").length;
  const completed = tasks.filter((t) => t.status === "completed").length;

  return (
    <div className="min-w-screen flex flex-row justify-center">
      <div className="max-w-3xl mx-auto bg-white shadow-xl rounded-xl p-6 space-y-6">
        <h1 className="text-4xl font-bold text-indigo-600 text-center"> To-Do List</h1>

        {/* Task Form */}
        <form
          onSubmit={handleSubmit}
          className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-end"
        >
          <input
            type="text"
            placeholder="Task title"
            value={title}
            required
            onChange={(e) => setTitle(e.target.value)}
            className="p-3 border rounded-md col-span-full sm:col-span-2 focus:ring-indigo-500 focus:ring-2"
          />
          <input
            type="date"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
            className="p-3 border rounded-md"
          />
          <select
            value={priority}
            onChange={(e) => setPriority(e.target.value)}
            className="p-3 border rounded-md"
          >
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
          </select>
          <button
            type="submit"
            className="col-span-full bg-indigo-600 text-black py-3 rounded-md hover:bg-indigo-700 transition"
          >
            ➕ Add Task
          </button>
        </form>

        {/* Controls */}
        <div className="flex flex-col sm:flex-row justify-between items-center gap-3">
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="p-2 border rounded-md w-full sm:w-auto"
          >
            <option value="">All</option>
            <option value="pending">Pending</option>
            <option value="completed">Completed</option>
          </select>
          <input
            type="text"
            placeholder="🔍 Search tasks..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="p-2 border rounded-md w-full sm:w-1/2"
          />
        </div>

        {/* Summary */}
        <div className="text-center text-sm text-gray-600">
          Total: {tasks.length} | Completed: {completed} | Pending: {pending}
        </div>

        {/* Task List */}
        <ul className="space-y-4">
          {filteredTasks.length === 0 ? (
            <li className="text-center text-red-400">No tasks found.</li>
          ) : (
            filteredTasks.map((task) => (
              <li
                key={task._id}
                className="flex justify-between items-start p-4 bg-gray-50 border rounded-md shadow-sm hover:shadow-md transition"
              >
                <div>
                  <h3
                    className={`text-lg font-medium ${
                      task.status === "completed" ? "line-through text-gray-400" : "text-gray-800"
                    }`}
                  >
                    {task.title}
                  </h3>
                  <div className="text-sm text-gray-500 mt-1 space-x-2">
                    {task.dueDate && (
                      <span>📅 {new Date(task.dueDate).toLocaleDateString()}</span>
                    )}
                    <span
                      className={`inline-block px-2 py-0.5 rounded-full text-xs font-semibold ${
                        task.priority === "High"
                          ? "bg-red-100 text-red-600"
                          : task.priority === "Medium"
                          ? "bg-yellow-100 text-yellow-700"
                          : "bg-green-100 text-green-700"
                      }`}
                    >
                      {task.priority}
                    </span>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => updateTask(task._id, task.status)}
                    title="Toggle Status"
                    className="text-green-600 hover:text-green-800 text-xl"
                  >
                    {task.status === "pending" ? "✔️" : "↩️"}
                  </button>
                  <button
                    onClick={() => deleteTask(task._id)}
                    title="Delete"
                    className="text-red-500 hover:text-red-700 text-xl"
                  >
                    🗑️
                  </button>
                </div>
              </li>
            ))
          )}
        </ul>

        {/* Footer */}
       
      </div>
    </div>
  );
}

export default App;
